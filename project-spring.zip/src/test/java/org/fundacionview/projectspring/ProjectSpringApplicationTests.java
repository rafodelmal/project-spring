package org.fundacionview.projectspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
